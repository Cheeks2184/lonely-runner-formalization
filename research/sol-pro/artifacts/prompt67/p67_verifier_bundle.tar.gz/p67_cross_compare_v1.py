#!/usr/bin/env python3
"""Cross-compare the two independent Prompt 67 verifiers."""
from __future__ import annotations

from hashlib import sha256
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
literal_path = ROOT / 'p67_literal_v1.jsonl'
orbit_path = ROOT / 'p67_orbit_bitset_v1.jsonl'

literal = [json.loads(line) for line in literal_path.read_text().splitlines() if line.strip()]
orbit = [json.loads(line) for line in orbit_path.read_text().splitlines() if line.strip()]
assert len(literal) == len(orbit) == 5

fields = [
    'scope', 'n', 'N', 'p', 'M', 'tuple_total', 'premise_total',
    'failure_total', 'success_total', 'first_failure',
    'first_failure_cover_first_bad_index_by_r', 'first_failure_distance_rows',
    'first_witness_histogram', 'first_witness_boundary_tuple_count',
    'outcome_map_encoding', 'failure_cover_record_count',
    'failure_cover_encoding', 'tuple_order', 'global_early_stop',
]
rows = []
for a, b in zip(literal, orbit, strict=True):
    assert (a['n'], a['p']) == (b['n'], b['p'])
    mismatches = [field for field in fields if a[field] != b[field]]
    assert not mismatches, ((a['n'], a['p']), mismatches)

    literal_map = ROOT / a['outcome_map_file']
    orbit_map = ROOT / b['outcome_map_file']
    literal_bytes = literal_map.read_bytes()
    orbit_bytes = orbit_map.read_bytes()
    assert len(literal_bytes) == len(orbit_bytes) == a['tuple_total']
    assert literal_bytes == orbit_bytes, (a['n'], a['p'], 'outcome map mismatch')
    map_sha = sha256(literal_bytes).hexdigest()
    assert map_sha == b['outcome_map_sha256']

    literal_failure = (ROOT / a['failure_cover_file']).read_bytes()
    orbit_failure = (ROOT / b['failure_cover_file']).read_bytes()
    expected_failure_bytes = a['failure_total'] * (8 + a['M'])
    assert len(literal_failure) == len(orbit_failure) == expected_failure_bytes
    assert literal_failure == orbit_failure, (a['n'], a['p'], 'failure cover mismatch')
    failure_sha = sha256(literal_failure).hexdigest()
    assert failure_sha == b['failure_cover_sha256']

    rows.append({
        'n': a['n'],
        'p': a['p'],
        'matched_fields': fields,
        'premise_total': a['premise_total'],
        'failure_total': a['failure_total'],
        'first_failure': a['first_failure'],
        'outcome_map_byte_count': len(literal_bytes),
        'outcome_map_sha256': map_sha,
        'outcome_maps_byte_identical': True,
        'failure_cover_byte_count': len(literal_failure),
        'failure_cover_sha256': failure_sha,
        'failure_covers_byte_identical': True,
    })

report = {
    'verifier': 'p67-cross-compare-v1',
    'literal_source': literal_path.name,
    'orbit_source': orbit_path.name,
    'case_count': len(rows),
    'all_fields_match': True,
    'all_outcome_maps_byte_identical': True,
    'all_failure_cover_streams_byte_identical': True,
    'rows': rows,
}
print(json.dumps(report, indent=2, sort_keys=True))
