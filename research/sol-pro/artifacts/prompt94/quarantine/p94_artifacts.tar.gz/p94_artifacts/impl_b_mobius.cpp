#include <algorithm>
#include <climits>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <numeric>
#include <sstream>
#include <string>
#include <tuple>
#include <utility>
#include <vector>
using namespace std;

struct Row { long long p,M,phi,covered,def; vector<pair<long long,long long>> K; };

static vector<pair<long long,int>> factorize(long long n){
    vector<pair<long long,int>> f;
    for(long long q=2;q*q<=n;q+=(q==2?1:2)) if(n%q==0){
        int e=0; do{n/=q;++e;}while(n%q==0); f.push_back({q,e});
    }
    if(n>1)f.push_back({n,1}); return f;
}
static vector<long long> all_divisors(long long n){
    vector<long long>d{1};
    for(auto [p,e]:factorize(n)){
        auto old=d;
        d.clear(); long long z=1;
        for(int k=0;k<=e;k++){for(long long x:old)d.push_back(x*z);z*=p;}
    }
    sort(d.begin(),d.end());return d;
}
static int mob(long long n){
    if(n==1)return 1; int w=0;
    for(auto [p,e]:factorize(n)){if(e>1)return 0;++w;}
    return (w&1)?-1:1;
}
static long long euler_phi(long long n){
    long long z=n; for(auto [p,e]:factorize(n))z=z/p*(p-1); return z;
}
static bool strict_bad(long long r,long long owner,long long M,long long p){
    long long y=(__int128)r*owner%M;
    return y<p || y>M-p; // equality at p and M-p is safe
}
static Row row_B(const vector<long long>&a,int j,bool keepK=false){
    const long long n=a.size(),N=n+1,p=a[j],M=N*p;
    vector<long long> ds=all_divisors(M),K(ds.size(),0);
    // No gcd(r,M)=1 filter occurs here. Construct every divisibility layer on R.
    for(long long r=0;r<M;r++){
        if(r%N==0)continue;
        bool covered=false;
        for(int i=0;i<(int)n;i++)if(i!=j && strict_bad(r,a[i],M,p)){covered=true;break;}
        if(!covered)continue;
        for(size_t z=0;z<ds.size();z++)if(r%ds[z]==0)K[z]++;
    }
    long long cu=0;for(size_t z=0;z<ds.size();z++)cu+=(long long)mob(ds[z])*K[z];
    Row out{p,M,euler_phi(M),cu,euler_phi(M)-cu,{}};
    if(keepK)for(size_t z=0;z<ds.size();z++)out.K.push_back({ds[z],K[z]});
    return out;
}
static pair<long long,vector<Row>> eval(const vector<long long>&a,bool keepK=false){
    long long om=0;vector<Row> rows;
    for(int j=0;j<(int)a.size();j++){auto r=row_B(a,j,keepK);om+=r.def;rows.push_back(move(r));}
    return {om,rows};
}
static bool primitive(const vector<long long>&a){long long g=0;for(auto x:a)g=gcd(g,x);return g==1;}
static string tuple_json(const vector<long long>&a){ostringstream o;o<<"[";for(size_t i=0;i<a.size();i++){if(i)o<<",";o<<a[i];}o<<"]";return o.str();}
static string defs_json(const vector<Row>&r){ostringstream o;o<<"[";for(size_t i=0;i<r.size();i++){if(i)o<<",";o<<r[i].def;}o<<"]";return o.str();}

struct MinRec{long long om=LLONG_MAX;vector<long long>a;vector<Row>rows;long long count=0;};

static void comb_rec(int n,int next,vector<long long>&cur, long long &raw,long long&primc,MinRec&mn,bool&failure){
    if((int)cur.size()==n){
        raw++; if(!primitive(cur))return; primc++;
        auto [om,rows]=eval(cur);
        if(om<mn.om){mn.om=om;mn.a=cur;mn.rows=rows;}
        if(om==0)failure=true; return;
    }
    int need=n-(int)cur.size();
    for(int x=next;x<=18-need+1 && !failure;x++){cur.push_back(x);comb_rec(n,x+1,cur,raw,primc,mn,failure);cur.pop_back();}
}

static vector<long long> parse_tuple(const string&s){istringstream in(s);vector<long long>a;long long x;while(in>>x)a.push_back(x);return a;}

int main(int argc,char**argv){
    string manifest=argc>1?argv[1]:"structured_mutations.csv";
    struct CountRec{int n;long long raw,prim;MinRec mn;};vector<CountRec> pre;bool pfail=false;
    for(int n=2;n<=5 && !pfail;n++){
        vector<long long>cur;long long raw=0,pc=0;MinRec mn;comb_rec(n,1,cur,raw,pc,mn,pfail);pre.push_back({n,raw,pc,mn});
    }
    map<int,MinRec> groups;bool sfail=false;long long stotal=0;
    ifstream f(manifest);string line;getline(f,line);
    while(getline(f,line)){
        size_t c1=line.find(','),c2=line.find(',',c1+1); if(c1==string::npos||c2==string::npos)continue;
        int n=stoi(line.substr(0,c1));vector<long long>a=parse_tuple(line.substr(c1+1,c2-c1-1));
        auto [om,rows]=eval(a);stotal++;auto &g=groups[n];g.count++;
        if(om<g.om){g.om=om;g.a=a;g.rows=rows;}
        if(om==0){sfail=true;break;}
    }
    vector<vector<long long>> hands={{1,2},{1,3},{1,2,3},{1,3,4},{1,3,13},{4,5,9},{1,2,3,4,5,7},{2,6,8},
      {6,7,12,24,144},{15,21,40,48,56,105,126,280,1200},{1,2,5,7,9,11,12,13},{1,5,7,8,9,11,13,15}};

    cout<<"{\"implementation\":\"B-divisor-layers-mobius\",\"preflight_counts\":[";
    for(size_t i=0;i<pre.size();i++){if(i)cout<<",";auto &x=pre[i];cout<<"{\"n\":"<<x.n<<",\"raw\":"<<x.raw<<",\"primitive\":"<<x.prim<<"}";}
    cout<<"],\"preflight_minima\":[";
    for(size_t i=0;i<pre.size();i++){if(i)cout<<",";auto &x=pre[i];cout<<"{\"n\":"<<x.n<<",\"Omega_min\":"<<x.mn.om<<",\"tuple\":"<<tuple_json(x.mn.a)<<",\"DefUnit_rows\":"<<defs_json(x.mn.rows)<<"}";}
    cout<<"],\"preflight_failure\":"<<(pfail?"true":"false")<<",\"structured_seed\":940283,\"structured_total\":"<<stotal
        <<",\"structured_complete\":"<<((!sfail&&stotal==6000)?"true":"false")<<",\"structured_groups\":[";
    bool first=true;for(auto &[n,g]:groups){if(!first)cout<<",";first=false;cout<<"{\"n\":"<<n<<",\"count\":"<<g.count<<",\"Omega_min\":"<<g.om<<",\"tuple\":"<<tuple_json(g.a)<<",\"DefUnit_rows\":"<<defs_json(g.rows)<<"}";}
    cout<<"],\"structured_failure\":"<<(sfail?"true":"false")<<",\"hand_and_stress\":[";
    for(size_t h=0;h<hands.size();h++){
        if(h)cout<<",";auto [om,rows]=eval(hands[h],true);cout<<"{\"a\":"<<tuple_json(hands[h])<<",\"OmegaUnit\":"<<om<<",\"rows\":[";
        for(size_t j=0;j<rows.size();j++){if(j)cout<<",";auto&r=rows[j];cout<<"{\"p\":"<<r.p<<",\"M\":"<<r.M<<",\"phi\":"<<r.phi<<",\"CoveredUnit\":"<<r.covered<<",\"DefUnit\":"<<r.def<<",\"K\":{";
            for(size_t z=0;z<r.K.size();z++){if(z)cout<<",";cout<<"\""<<r.K[z].first<<"\":"<<r.K[z].second;}cout<<"}}";
        }cout<<"]}";
    }
    cout<<"]}\n";
}
