#!/usr/bin/env python3
import json
from pathlib import Path
H=Path(__file__).resolve().parent
A=json.load((H/'impl_a_output.json').open())
B=json.load((H/'impl_b_output.json').open())
checks={}
checks['preflight_counts']=A['preflight_counts']==B['preflight_counts']
checks['preflight_minima']=A['preflight_minima']==B['preflight_minima']
checks['structured_total']=A['structured_total']==B['structured_total']==6000
checks['structured_complete']=A['structured_complete'] and B['structured_complete']
checks['structured_groups']=A['structured_groups']==B['structured_groups']
checks['no_failures']=(not A['preflight_failures'] and not A['structured_failures'] and not B['preflight_failure'] and not B['structured_failure'])
# Compare hand/stress scalar rows; A has direct safe sets, B has divisor layers.
scalar_equal=True
for xa,xb in zip(A['hand_and_stress'],B['hand_and_stress']):
    scalar_equal &= xa['a']==xb['a'] and xa['OmegaUnit']==xb['OmegaUnit']
    scalar_equal &= [(r['p'],r['M'],r['phi'],r['CoveredUnit'],r['DefUnit']) for r in xa['rows']] == [(r['p'],r['M'],r['phi'],r['CoveredUnit'],r['DefUnit']) for r in xb['rows']]
checks['hand_stress_scalars']=bool(scalar_equal)
out={'checks':checks,'all_pass':all(checks.values())}
print(json.dumps(out,sort_keys=True,separators=(',',':')))
