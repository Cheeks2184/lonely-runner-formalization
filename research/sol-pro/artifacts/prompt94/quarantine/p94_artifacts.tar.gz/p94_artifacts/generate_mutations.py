#!/usr/bin/env python3
import csv, math, random
from pathlib import Path

SEED=940283
TARGET_PER_DIM=750
BASES={
2:[(1,2),(1,3),(5,7),(4,9),(6,12)],
3:[(1,2,3),(1,3,4),(1,3,13),(4,5,9),(2,6,8),(2,3,5),(4,8,16)],
4:[(1,2,3,4),(2,3,5,7),(5,10,15,20),(1,4,16,64)],
5:[(1,2,3,4,5),(6,7,12,24,144),(2,3,5,7,11),(1,5,25,125,625),(6,12,18,24,30)],
6:[(1,2,3,4,5,6),(1,2,3,4,5,7),(2,3,5,7,11,13),(7,14,21,28,35,42)],
7:[(1,2,3,4,5,6,7),(2,3,5,7,11,13,17),(8,16,24,32,40,48,56)],
8:[(1,2,3,4,5,6,7,8),(1,2,5,7,9,11,12,13),(1,5,7,8,9,11,13,15),(2,3,5,7,11,13,17,19)],
9:[(1,2,3,4,5,6,7,8,9),(15,21,40,48,56,105,126,280,1200),(2,3,5,7,11,13,17,19,23)],
}

def canonical(t): return tuple(sorted(t))

def permuted(c, rng):
    v=list(c)
    # deterministic nontrivial Fisher-Yates permutation
    rng.shuffle(v)
    if tuple(v)==c and len(v)>1:
        v[0],v[1]=v[1],v[0]
    return tuple(v)

def valid(c): return all(x>0 for x in c) and len(set(c))==len(c)

def generate_dim(n,bases,rng,target):
    N=n+1
    cap=max(240,max(max(b) for b in bases))
    seen=set(); rows=[]
    def add(c,tag):
        if not valid(c): return
        key=canonical(c)
        if key in seen:return
        seen.add(key)
        rows.append((permuted(key,rng),tag))
    # Exact bases, nontrivial permutations, and common scales. These are mandatory.
    for bi,b in enumerate(bases):
        add(b,f'base:{bi}')
        for h in (2,3,5,7):
            if max(b)*h <= max(cap, max(b)*7):
                add(tuple(h*x for x in b),f'scale:{bi}:{h}')
    deltas=(-2*N,-N,-3,-2,-1,1,2,3,N,2*N)
    ops=('delta','double_plus','half_plus','affine')
    attempts=0
    while len(rows)<target:
        attempts+=1
        if attempts>2_000_000: raise RuntimeError((n,len(rows)))
        bi=rng.randrange(len(bases)); c=list(bases[bi])
        k=1+rng.randrange(min(3,n))
        idxs=rng.sample(range(n),k)
        for idx in idxs:
            op=ops[rng.randrange(len(ops))]
            x=c[idx]
            if op=='delta': y=x+rng.choice(deltas)
            elif op=='double_plus': y=2*x+rng.choice((-N,-1,1,N))
            elif op=='half_plus': y=max(1,x//2)+rng.choice((0,1,N))
            else:
                mul=rng.choice((1,2,3,5)); y=mul*x+rng.choice((-2,-1,1,2))
            # fold deterministically into a positive bounded range, retaining arithmetic structure
            bound=cap
            y=((y-1)%bound)+1
            c[idx]=y
        if not valid(c):continue
        add(tuple(c),f'mut:{bi}:{attempts}')
    return rows

def main():
    rng=random.Random(SEED)
    out=Path(__file__).with_name('structured_mutations.csv')
    counts={}
    with out.open('w',newline='') as f:
        w=csv.writer(f);w.writerow(['n','tuple','tag'])
        for n in sorted(BASES):
            rows=generate_dim(n,BASES[n],rng,TARGET_PER_DIM)
            counts[n]=len(rows)
            for tup,tag in rows:w.writerow([n,' '.join(map(str,tup)),tag])
    print('seed',SEED,'counts',counts,'total',sum(counts.values()),'path',out)
if __name__=='__main__':main()
