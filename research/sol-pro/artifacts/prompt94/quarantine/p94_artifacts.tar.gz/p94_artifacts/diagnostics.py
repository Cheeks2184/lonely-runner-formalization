#!/usr/bin/env python3
import json,math

def rho(x,m):
 y=x%m;return min(y,m-y)
def row_defs(a):
 n=len(a);N=n+1;out=[]
 for j,p in enumerate(a):
  M=N*p;safe=0
  for r in range(M):
   if math.gcd(r,M)!=1:continue
   if all(i==j or rho(r*a[i],M)>=p for i in range(n)):safe+=1
  out.append(safe)
 return out
def first_moment(a):
 n=len(a);N=n+1;tot=0;rows=[]
 for j,p in enumerate(a):
  M=N*p;U=[r for r in range(M) if math.gcd(r,M)==1]
  counts=[]
  for i,x in enumerate(a):
   if i!=j:counts.append(sum(rho(r*x,M)<p for r in U))
  delta=len(U)-sum(counts);tot+=delta;rows.append(delta)
 return tot,rows
def primes(n):
 p=2
 while p*p<=n:
  if n%p==0:
   yield p
   while n%p==0:n//=p
  p+=1
 if n>1:yield n
def phi(n):
 z=n
 for p in primes(n):z=z//p*(p-1)
 return z
def slambda(h,M):
 s=1
 for p in primes(h):
  if M%p:s*=p
 return s,(h//s)*phi(s)
def scaling(base,h):
 return [{'M':(len(base)+1)*p,'s':slambda(h,(len(base)+1)*p)[0],'lambda':slambda(h,(len(base)+1)*p)[1],
          'baseDef':row_defs(base)[j],'scaledDef':row_defs(tuple(h*x for x in base))[j]} for j,p in enumerate(base)]
def ramanujan(M,k):
 return sum(complex(math.cos(-2*math.pi*k*r/M),math.sin(-2*math.pi*k*r/M)) for r in range(M) if math.gcd(r,M)==1)
out={
 'first_moment':{
  '1,2,3,4,5,7':first_moment((1,2,3,4,5,7)),
  '15,21,40,48,56,105,126,280,1200':first_moment((15,21,40,48,56,105,126,280,1200))},
 'scaling_1,3,4':{str(h):scaling((1,3,4),h) for h in (2,5,6)},
 'permutation':{
  '1,3,4':row_defs((1,3,4)), '4,1,3':row_defs((4,1,3)), '3,4,1':row_defs((3,4,1))},
 'boundary':{'rho12_3':rho(3,12),'strict_bad':rho(3,12)<3,'weak_bad':rho(3,12)<=3},
 'collision_sets':{},
 'ramanujan_M12':{str(k):round(ramanujan(12,k).real) for k in range(12)},
 'crt_M12_p3_owner1':{'unit_points':{'1':[1,1],'5':[1,2],'7':[3,1],'11':[3,2]},'bad_units':[1,11]},
}
A=(1,3,13);j=1;N=4;p=3;M=12
for i in (0,2):out['collision_sets'][str(A[i])]=[r for r in range(M) if r%N and rho(r*A[i],M)<p]
print(json.dumps(out,sort_keys=True,separators=(',',':')))
