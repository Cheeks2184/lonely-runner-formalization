#!/usr/bin/env python3
"""Prompt 94 implementation A: direct unit-residue oracle only."""
import csv, itertools, json, math, platform, sys
from pathlib import Path

HERE=Path(__file__).resolve().parent

def rho(x,m):
    y=x%m
    return y if y<=m-y else m-y

def row(a,j,with_safe=False):
    n=len(a);N=n+1;p=a[j];M=N*p
    covered=0;safe=[];units=0
    for r in range(1,M):
        if math.gcd(r,M)!=1:continue
        units+=1
        bad=False
        for i,x in enumerate(a):
            if i!=j and rho(r*x,M)<p:
                bad=True;break
        if bad:covered+=1
        elif with_safe:safe.append(r)
    return {'p':p,'M':M,'phi':units,'CoveredUnit':covered,'DefUnit':units-covered,'safe':safe if with_safe else None}

def eval_tuple(a,with_safe=False):
    rows=[row(a,j,with_safe) for j in range(len(a))]
    return sum(x['DefUnit'] for x in rows),rows

def primitive(a):
    g=0
    for x in a:g=math.gcd(g,x)
    return g==1

def preflight():
    counts=[];failures=[];mins=[]
    for n in range(2,6):
        raw=prim=0;best=None;besta=None;bestds=None
        for a in itertools.combinations(range(1,19),n):
            raw+=1
            if not primitive(a):continue
            prim+=1;om,rows=eval_tuple(a)
            ds=[r['DefUnit'] for r in rows]
            if best is None or om<best:best,besta,bestds=om,a,ds
            if om==0:failures.append({'n':n,'a':a,'rows':rows});break
        counts.append({'n':n,'raw':raw,'primitive':prim})
        mins.append({'n':n,'Omega_min':best,'tuple':besta,'DefUnit_rows':bestds})
        if failures:break
    return counts,mins,failures

def structured():
    groups={};failures=[];total=0
    with (HERE/'structured_mutations.csv').open(newline='') as f:
        rd=csv.DictReader(f)
        for rec in rd:
            n=int(rec['n']);a=tuple(map(int,rec['tuple'].split()));total+=1
            om,rows=eval_tuple(a)
            ds=[x['DefUnit'] for x in rows]
            g=groups.setdefault(n,{'count':0,'Omega_min':None,'tuple':None,'DefUnit_rows':None})
            g['count']+=1
            if g['Omega_min'] is None or om<g['Omega_min']:
                g.update(Omega_min=om,tuple=a,DefUnit_rows=ds)
            if om==0:
                failures.append({'n':n,'a':a,'tag':rec['tag'],'rows':rows});break
        # deliberate completion check: consume all rows unless failure
        complete=(not failures and total==6000)
    return [dict(n=n,**groups[n]) for n in sorted(groups)],failures,complete,total

def hand():
    tests=[(1,2),(1,3),(1,2,3),(1,3,4),(1,3,13),(4,5,9),(1,2,3,4,5,7),(2,6,8),
           (6,7,12,24,144),(15,21,40,48,56,105,126,280,1200),
           (1,2,5,7,9,11,12,13),(1,5,7,8,9,11,13,15)]
    out=[]
    for a in tests:
        om,rows=eval_tuple(a,True)
        out.append({'a':a,'OmegaUnit':om,'rows':rows})
    return out

def main():
    counts,mins,pfail=preflight()
    sgroups,sfail,scomplete,stotal=structured()
    out={
      'implementation':'A-direct-unit-oracle',
      'language':sys.version.split()[0],
      'platform':platform.machine(),
      'preflight_counts':counts,
      'preflight_minima':mins,
      'preflight_failures':pfail,
      'structured_seed':940283,
      'structured_total':stotal,
      'structured_complete':scomplete,
      'structured_groups':sgroups,
      'structured_failures':sfail,
      'hand_and_stress':hand(),
    }
    print(json.dumps(out,sort_keys=True,separators=(',',':')))
if __name__=='__main__':main()
